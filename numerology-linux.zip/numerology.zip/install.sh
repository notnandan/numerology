#!/bin/bash

SOURCE="numerology_linux"
DEST="/usr/local/bin/numerology"

# 1. Check if the binary exists
if [ ! -f "$SOURCE" ]; then
    echo "Error: $SOURCE not found in this folder."
    echo "Current folder: $(pwd)"
    exit 1
fi

echo "Installing Numerology to WSL Debian..."

# 2. Copy and rename
sudo cp -f "$SOURCE" "$DEST"

# 3. Set execution permissions
sudo chmod +x "$DEST"

# 4. Refresh Bash's command memory
hash -r

if [ $? -eq 0 ]; then
    echo "------------------------------------------------"
    echo "SUCCESS: Installed to $DEST"
    echo "Try it now by typing: numerology"
    echo "------------------------------------------------"
else
    echo "Installation failed. Make sure you have sudo rights."
fi